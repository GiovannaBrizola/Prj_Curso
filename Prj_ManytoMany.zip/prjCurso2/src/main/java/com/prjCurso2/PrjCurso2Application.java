package com.prjCurso2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjCurso2Application {

	public static void main(String[] args) {
		SpringApplication.run(PrjCurso2Application.class, args);
	}

}
